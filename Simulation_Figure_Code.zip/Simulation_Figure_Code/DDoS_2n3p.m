function [t,y] = DDoS_2n3p(N0, ratio, dilution, antibiotic, ISceI, time)
%N0 is the starting density of the total community
%Ratio is the starting ratio of the resident population to the DoS population
%D is the dilution rate
%Ant concentration of Cm betweeen 0-1 (higher Cm means more growth suppression)
%ISceI is the level of aTc induction
%time is the simulation time

% [t,y] = DDoS_2n3p(1e-6, 1, 0.05, 0.15, 0.01, 2e4); %Single time course for two starting cells
%% Making the permutations of the different combinations of plasmids
num_plas = 3;
pop = 2;
temp = zeros(1,num_plas);
indexes = zeros(1,num_plas);

for i = 1:num_plas
    temp(1:i) = 1;
    permutation = unique(perms(temp), 'rows');
    indexes = [indexes; permutation];
end
 
%Duplicate and append a column designating which population
indexes = repmat(indexes, 2, 1);
pop_col = zeros(pop*2^num_plas,1);
pop_col(size(pop_col)/2+1:end,1) = 1;

subpop = [pop_col indexes];

%% ODE parameters %%

tspan = [0 time]; %units in Hr

%Initial condition
y0 = zeros(16,1);
y0(3) = N0;
y0(4) = N0;
% y0(7) = N0;
y0(10) = N0/ratio;

parameters = {dilution antibiotic ISceI time subpop};
options = odeset('NonNegative',[1:16]);
[t,y] = ode45(@(t,y) DDoS(t,y,parameters), tspan, y0, options);

%% Plotting %%

y(y < 1e-9) = 0; %Any fraction less than 1e-8 is less than a cell
stacks= y ./sum(y,2); %Changing the time courses to fractional populations

% figure()
% g = area(t, stacks);
% hold on
% midline = line([.75*time .75*time], [0 1]);
% set(midline, 'Linewidth', 3, 'Color', 'k', 'LineStyle', '--')
% hold off
% legend(cellstr(num2str(subpop)))
% xlim([0 time])
% ylim([0 1])
% set(gca, 'Xticklabel', [])
% set(gca, 'Yticklabel', [])
% 
% cd /Users/ryantsoi/Desktop/Lab/Conjugation/New_MATLAB/Simulation_Figures/
% set(gcf, 'PaperPositionMode', 'auto');
% print('DDoS_2n3p_1_SP','-dpng','-r300');
% close;

stack0 = sum(stacks(:,find(subpop(:,2) == 0 & subpop(:,3) == 0 & subpop(:,4) == 0)),2);
stackF = sum(stacks(:, find(subpop(:,2) == 1)) ,2);
stackR = sum(stacks(:, find(subpop(:,3) == 1)) ,2);
stackD = sum(stacks(:, find(subpop(:,4) == 1)) ,2); 

figure()
g = plot(t, [stack0 stackF stackR stackD], 'LineWidth', 3);
g(1).Color = [85 85 85]/255; 
g(2).Color = [0 153 0]/255; 
g(3).Color = [0 0 153]/255; 
g(4).Color = [153 0 0]/255; 
hold on
xline(0.75*t(end), 'Linewidth', 2, 'Color', 'k', 'LineStyle', '--');
hold off
xlim([0 t(end)])
ylim([0 1.2])
set(gca, 'Xticklabel', [])
set(gca, 'Yticklabel', [])
set(gca,'Box','on');

cd /Users/ryantsoi/Desktop/Lab/Conjugation/New_MATLAB/Simulation_Figures/
set(gcf, 'PaperPositionMode', 'auto');
print('DDoS_2n3p_Multi','-dpng','-r300');
% close;

function dydt = DDoS(Time,y,p) 
%% Parameters (based from Allie's model/supplementary) %%

%If density drops below 1 cell, then the population has died out completely 
y(y < 1e-9) = 0;

%Growth rates and relative plasmid burdens%
alphad = 1/1.21; %Natural burden of DoS plasmid
alphaf = [1/0.81 1/0.9]; %Natural burden of conjugative plasmid
K = 1; %Carrying capacity

%Antibiotic
burden = 1-p{2}; %Degree of Cm suppression of growth
benefit = 1+p{2};  %Degree of Cm growth benefit

%Dilution
D = p{1}; %Allie number is 0.05
%D = 0.05 --> %Dilution rate in Hr-1 (reflects 10^4 daily dilution fold)

%Growth%
subpop = p{5};
growth = [repmat(0.33, 1, 8) repmat(0.3, 1, 8)];
B = ones(1,16);

if Time <= .75*p{4} && p{2} > 0
    %Growth matrix 
    B(subpop(:,2) == 1 | subpop(:,3) == 0) = alphaf(1)*burden;
    B(subpop(:,2) == 0 | subpop(:,3) == 1) = alphaf(2)*burden;
    B(subpop(:,2) == 1 & subpop(:,3) == 1)  = prod(alphaf)*burden^2;
    B(subpop(:,4) == 1) = benefit;
    %Overwrites B for special cases
    B(subpop(:,2) == 1 & subpop(:,4) == 1) = alphaf(1)*benefit;
    B(subpop(:,3) == 1 & subpop(:,4) == 1) = alphaf(2)*benefit;
    B(subpop(:,2) == 1 & subpop(:,3) == 1 & subpop(:,4) == 1) = prod(alphaf)*benefit;
    u = growth.*B;
    
    ISceI = 0;
else
    %Growth matrix 
    B(subpop(:,2) == 1 | subpop(:,3) == 0) = alphaf(1);
    B(subpop(:,2) == 0 | subpop(:,3) == 1) = alphaf(2);
    B(subpop(:,2) == 1 & subpop(:,3) == 1) = prod(alphaf);
    B(subpop(:,4) == 1)  = alphad;
    %Overwrites B for special cases
    B(subpop(:,2) == 1 & subpop(:,4) == 1) = alphaf(1)*alphad;
    B(subpop(:,3) == 1 & subpop(:,4) == 1) = alphaf(2)*alphad;
    B(subpop(:,2) == 1 & subpop(:,3) == 1 & subpop(:,4) == 1) = prod(alphaf)*alphad;
    u = growth.*B;

    ISceI = p{3};
    
end

% Segregation error%
sigmaD = 1e-4; %Segregation error of DoS
sigmaC = 1e-4; %Segregation error of conjugative plasmid

% Conjugation rates%
etaF0 = 1.76e-3; %Allie's number for RP4

%Cotransfer/Retrotransfer
etaF1 = etaF0/10; %Conjugation of conjugative plasmid (suppressed by DoS)
etaD = etaF0; %Conjugation of DoS becomes the same as base number from experimental data
etaB = etaF0/100; %Conjugation of both plasmids
etaRet = etaF0/100; %1% of all conjugation events become retrotransfer (hence the observed 100-fold slower)

%Translating conjugation variables%
etaF = [etaF0 etaF1];
etaR = [etaF0*1.1 etaF1*1.1];
etaBf = etaB;
etaBr = etaB;
etaDf = etaD;
etaDr = etaD;

%Incompatibility (the same rate as growth)
gamma = [growth(1) growth(9)]; 

%% ODEs %%
%This is a full model of the long term experiments 
%M_000: empty cells%
dydt(1,1) = u(1)*y(1)*(1-sum(y)/K)...
    - etaF(1)*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F0_ + 000
    - etaR(1)*y(1)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + 000
    - (etaF(2)+etaDf+etaBf)*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 000 (co)
    - (etaR(2)+etaDr+etaBr)*y(1)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 000 (co)
    + (sigmaD+ISceI)*y(2) + sigmaC*(y(3)+y(4)) - D*y(1);
%M_00D: Cells with DDoS%
dydt(2,1) = u(2)*y(2)*(1-sum(y)/K)...
    + etaDf*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 000
    + etaDr*y(1)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 000
    - etaF(1)*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 00D
    - etaF(2)*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 00D
    - etaR(1)*y(2)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + 00D
    - etaR(2)*y(2)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 00D
    - etaRet*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0)) ... F_0 + 00D (retro)
    - etaRet*y(2)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0)) ... _R0 + 00D (retro)
    + gamma(1)*(y(5)+y(6)) - (sigmaD+ISceI)*y(2) - D*y(2);
%M_0R0: Cells with RP4%
dydt(3,1) = u(3)*y(3)*(1-sum(y)/K)...
    + etaR(1)*y(1)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + 000
    + etaR(2)*y(1)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 000
    - etaF(1)*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0R0
    - (etaF(2)+etaDf+etaBf)*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0R0
    - etaRet*sum(y(subpop(:,3) == 0 & subpop(:,4) == 1))*y(3)... 0R0 + _0D
    + (gamma(1)+ISceI)*y(5) + sigmaC*y(7) - sigmaC*y(3) - D*y(3);
%M_F00: Cells with F%
dydt(4,1) = u(4)*y(4)*(1-sum(y)/K)...
    + etaF(1)*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 000
    + etaF(2)*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 000
    - etaR(1)*y(4)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F00
    - (etaR(2)+etaDr+etaBr)*y(4)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + F00
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,4) == 1))*y(4)... F00 + 0_D
    + (gamma(1)+ISceI)*y(6) + sigmaC*y(7) - sigmaC*y(4) - D*y(4);
%M_0RD: Cells with RP4 and DDoS%
dydt(5,1) = u(5)*y(5)*(1-sum(y)/K)...
    + etaR(1)*y(2)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + 00D
    + etaR(2)*y(2)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 00D
    + etaBr*y(1)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 000
    + etaDf*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0R0
    + etaRet*y(2)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + 00D (retro)
    + etaRet*sum(y(subpop(:,3) == 0 & subpop(:,4) == 1))*y(3)... 0R0 + 0_D (double up counted)
    - etaF(1)*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0RD
    - etaF(2)*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0RD
    - etaRet*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0RD
    + gamma(1)*y(8) - (gamma(1)+ISceI)*y(5) - D*y(5);  
%M_F0D: Cells with F and DDoS%
dydt(6,1) = u(6)*y(6)*(1-sum(y)/K)...
    + etaF(1)*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 00D
    + etaF(2)*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 00D
    + etaBf*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 000
    + etaDr*y(4)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + F00
    + etaRet*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 00D (retro)
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,4) == 1))*y(4)... F00 + 0_D (double up counted)
    - etaR(1)*y(6)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F0D
    - etaR(2)*y(6)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + F0D
    - etaRet*y(6)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F0D
    + gamma(1)*y(8) - (gamma(1)+ISceI)*y(6) - D*y(6);
%M_FR0: Cells with F and RP4%
dydt(7,1) = u(7)*y(7)*(1-sum(y)/K)...
    + etaF(1)*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0R0
    + etaF(2)*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0R0
    + etaR(1)*y(4)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F00
    + etaR(2)*y(4)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + F00
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,4) == 1))*y(7)... FR0 + 0_D (retro via F)
    - etaRet*sum(y(subpop(:,3) == 0 & subpop(:,4) == 1))*y(7)... FR0 + _0D (retro via R)
    + (2*gamma(1)+ISceI)*y(8) - sigmaC*y(7) - D*y(7);
%M_FRD: Cells with F, RP4, and DDoS%
dydt(8,1) = u(8)*y(8)*(1-sum(y)/K)...
    + etaF(1)*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0RD
    + etaF(2)*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0RD
    + etaR(1)*y(6)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F0D
    + etaR(2)*y(6)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + F0D
    + etaBf*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0R0
    + etaBr*y(4)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))...  _RD + F00
    + etaRet*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0RD
    + etaRet*y(6)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F0D
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,4) == 1))*y(7)... FR0 + 0_D (double up counted)
    + etaRet*sum(y(subpop(:,3) == 0 & subpop(:,4) == 1))*y(7)... FR0 + _0D (double up counted)
    - (2*gamma(1)+ISceI)*y(8) - D*y(8);


%T_000: empty cells%
dydt(9,1) = u(9)*y(9)*(1-sum(y)/K)...
    - etaF(1)*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F0_ + 000
    - etaR(1)*y(9)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + 000
    - (etaF(2)+etaDf+etaBf)*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 000 (co)
    - (etaR(2)+etaDr+etaBr)*y(9)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 000 (co)
    + (sigmaD+ISceI)*y(10) + sigmaC*(y(11)+y(12)) - D*y(9);
%T_00D: Cells with DDoS%
dydt(10,1) = u(10)*y(10)*(1-sum(y)/K)...
    + etaDf*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 000
    + etaDr*y(9)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 000
    - etaF(1)*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 00D
    - etaF(2)*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 00D
    - etaR(1)*y(10)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + 00D
    - etaR(2)*y(10)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 00D
    - etaRet*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0)) ... F_0 + 00D (retro)
    - etaRet*y(10)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0)) ... _R0 + 00D (retro)
    + gamma(2)*(y(13)+y(14)) - (sigmaD+ISceI)*y(10) - D*y(10);
%T_0R0: Cells with RP4%
dydt(11,1) = u(11)*y(11)*(1-sum(y)/K)...
    + etaR(1)*y(9)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + 000
    + etaR(2)*y(9)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 000
    - etaF(1)*y(11)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0R0
    - (etaF(2)+etaDf+etaBf)*y(11)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0R0
    - etaRet*sum(y(subpop(:,3) == 0 & subpop(:,4) == 1))*y(11)... 0R0 + _0D
    + (gamma(2)+ISceI)*y(13) + sigmaC*y(15) - sigmaC*y(11) - D*y(11);
%T_F00: Cells with F%
dydt(12,1) = u(12)*y(12)*(1-sum(y)/K)...
    + etaF(1)*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 000
    + etaF(2)*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 000
    - etaR(1)*y(12)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F00
    - (etaR(2)+etaDr+etaBr)*y(12)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + F00
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,4) == 1))*y(12)... F00 + 0_D
    + (gamma(2)+ISceI)*y(14) + sigmaC*y(15) - sigmaC*y(12) - D*y(12);
%T_0RD: Cells with RP4 and DDoS%
dydt(13,1) = u(13)*y(13)*(1-sum(y)/K)...
    + etaR(1)*y(10)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + 00D
    + etaR(2)*y(10)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 00D
    + etaBr*y(9)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + 000
    + etaDf*y(11)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0R0
    + etaRet*y(10)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0)) ... _R0 + 00D (retro)
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,4) == 1))*y(11)... 0R0 + 0_D (double up counted)
    - etaF(1)*y(13)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0RD
    - etaF(2)*y(13)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0RD
    - etaRet*y(13)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0RD
    + gamma(2)*y(16) - (gamma(1)+ISceI)*y(13) - D*y(13);  
%T_F0D: Cells with F and DDoS%
dydt(14,1) = u(14)*y(14)*(1-sum(y)/K)...
    + etaF(1)*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 00D
    + etaF(2)*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 00D
    + etaBf*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 000
    + etaDr*y(12)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + F00
    + etaRet*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 00D (retro)
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,4) == 1))*y(12)... F00 + 0_D (double up counted)
    - etaR(1)*y(14)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F0D
    - etaR(2)*y(14)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + F0D
    - etaRet*y(14)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F0D
    + gamma(2)*y(16) - (gamma(1)+ISceI)*y(14) - D*y(14);
%T_FR0: Cells with F and RP4%
dydt(15,1) = u(15)*y(15)*(1-sum(y)/K)...
    + etaF(1)*y(11)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0R0
    + etaF(2)*y(11)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0R0
    + etaR(1)*y(12)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F00
    + etaR(2)*y(12)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + F00
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,4) == 1))*y(15)... FR0 + 0_D (retro via F)
    - etaRet*sum(y(subpop(:,3) == 0 & subpop(:,4) == 1))*y(15)... FR0 + _0D (retro via R)
    + (2*gamma(2)+ISceI)*y(16) - sigmaC*y(15) - D*y(15);
%T_FRD: Cells with F, RP4, and DDoS%
dydt(16,1) = u(16)*y(16)*(1-sum(y)/K)...
    + etaF(1)*y(13)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0RD
    + etaF(2)*y(13)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0RD
    + etaR(1)*y(14)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F0D
    + etaR(2)*y(14)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))... _RD + F0D
    + etaBf*y(11)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 1))... F_D + 0R0
    + etaBr*y(12)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 1))...  _RD + F00
    + etaRet*y(13)*sum(y(subpop(:,2) == 1 & subpop(:,4) == 0))... F_0 + 0RD
    + etaRet*y(14)*sum(y(subpop(:,3) == 1 & subpop(:,4) == 0))... _R0 + F0D
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,4) == 1))*y(15)... FR0 + 0_D (double up counted, Retro via F)
    + etaRet*sum(y(subpop(:,3) == 0 & subpop(:,4) == 1))*y(15)... FR0 + _0D (double up counted, Retro via R)
    - (2*gamma(2)+ISceI)*y(16) - D*y(16);

