%% Visualizing the parameter space of DoS for optimizing conditions
%This code will graph the effect of changing parameters on treatment time
%using heatmaps.

%Load data
load('Cluster_output.mat')

densities = 10.^[-4:1:-1]; %Range of starting densities from 10^4 to 10^7 cells. 
ratios = 10.^[0:1:3]; %Range of starting ratios (Resident:DoS) from 1:1 to 1000:1
dilutions = [0:0.0025:0.1]; %Range of dilution rates (0 dilution means no passaging)
Cm = [0:0.025:1]; %Antibiotic inhibition. 0 is no inhibition (Top10 always loses), 1 is complete inhibition (Top10 always win)

%Log scale data
t_treatment_log = log10(t_treatment/24);

%Densities and ratios indices matching experimental values
% The outer parameters will be N0 and R since their value ranges are 
% more discretized (experimentally) and we tested a narrower range of 
% these values experimentally. 
outerY = [find(densities == 1e-4) find(densities == 1e-3) find(densities == 1e-2 ) find(densities == 1e-1)]; 
outerX = [find(ratios == 1) find(ratios == 10) find(ratios == 100 ) find(ratios == 1000)]; 

% The inner parameters will be dilution and Cm since we tested more of
% these values experimentally. 
innerY = 1:length(Cm); %ratio range
innerX = 1:length(dilutions); %dilution range

%For loop to generate the individual heatmaps and arrange them using subplot
temp = 1; %temp value serves as subplot index and gets incremented every iteration
figure() %initialize figure

%A big paneled subplot for visualization of heatmap
%X-axis of inner heatmap is Cm, Y-axis of inner heatmap is Dilutions
%X-axis of outer heatmap is starting density, Y axis of outer heatmap is starting ratio
for a = 1:length(outerY)
    for b = 1:length(outerX)
        matrix_temp = squeeze(t_treatment_log(outerY(a), outerX(b), innerY, innerX));        
        
        %Subplotting
        p = subplot(length(outerY), length(outerX), temp);
        heatmap = imagesc(matrix_temp);
        
        xlabel('Dilutions')
%         xticks(1:10:41)
%         xticklabels(cellstr(num2str(dilutions(1:10:41))))
        
        ylabel('Cm')
%         yticks(1:10:41)
%         yticklabels(cellstr(num2str(Cm(1:10:41))))
        
        temp = temp + 1;
    end
end

c = colorbar;
set(c, 'Position', [.95 .1 .02 0.82])
