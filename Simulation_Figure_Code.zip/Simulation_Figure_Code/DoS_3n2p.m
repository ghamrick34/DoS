function [t,y] = DoS_3n2p(N0, ratio, dilution, antibiotic, ISceI, time)
%N0 is the starting density of the total community
%Ratio is the starting ratio of the resident population to the DoS population
%D is the dilution rate
%Ant concentration of Cm betweeen 0-1 (higher Cm means more growth suppression)
%ISceI is the level of aTc induction
%time is the simulation time

% [t,y] = DoS_3n2p(1e-2, 1000, 0.05, 0.7, 0.01, 1e4); %Single time course

%% Making the permutations of the different combinations of plasmids
plas = 2;
pop = 3;
temp = zeros(1,plas);
indexes = zeros(1,plas);

for i = 1:plas
    temp(1:i) = 1;
    permutation = unique(perms(temp), 'rows');
    indexes = [indexes; permutation];
end
 
%Duplicate and append a column designating which population
indexes = repmat(indexes, pop, 1);
pop_col = [];
for a = 1:pop
    pop_col = [pop_col ; repmat(a, 2^plas, 1)];
end

subpop = [pop_col indexes];

%% ODE parameters and running %%
%If changing order of equations, change this too
tspan = [0 time]; %units in Hr
y0 = [0; %MG1655
    0; %MG1655 DoS
    N0; %MG1655 RP4
    0; %MG1655 conjugative plasmid DoS
    0; %Top10
    N0/ratio; %Top10 DoS
    0; %Top10 RP4
    0; %Top10 conjugative plasmid DoS
    0; %J53
    0; %J53 DoS
    N0; %J53 RP4
    0; %J53 conjugative plasmid DoS
    ]; 
parameters = {dilution antibiotic ISceI time subpop};
options = odeset('NonNegative',[1:12]);

[t,y] = ode45(@(t,y) DoS(t,y,parameters), tspan, y0, options);


%% Plotting %%

y(y < 1e-9) = 0; %Any fraction less than 1e-9 is less than a cell (how the code was implemented)
stacks= y ./sum(y,2); %Changing the time courses to fractional populations

%%%% Subpopulation fractions %%%%
figure()
%g = area(t, stacks);
g = plot(t,stacks(:,  [ 1 3 2 4 5 7 6 8 9 11 10 12]));
hold on
xline(0.75*t(end), 'Linewidth', 3, 'Color', 'k', 'LineStyle', '--');
hold off
g(1).LineWidth = 1.5; 
g(2).LineWidth = 1.5; 
g(3).LineWidth = 1.5; 
g(4).LineWidth = 1.5; 
g(5).LineWidth = 1.5; 
g(6).LineWidth = 1.5; 
g(7).LineWidth = 1.5; 
g(8).LineWidth = 1.5; 
g(9).LineWidth = 1.5; 
g(10).LineWidth = 1.5; 
g(11).LineWidth = 1.5; 
g(12).LineWidth = 1.5; 
xlim([0 t(end)])
ylim([0 1])
set(gca,'Xtick',[])
set(gca, 'Xticklabel', [])
set(gca,'Ytick',[])
set(gca, 'Yticklabel', [])
legend('M', 'MR', 'MR', 'MRD', 'T', 'TR', 'TR', 'TRD', 'J', 'JR', 'JR', 'JRD')

% cd /Users/ryantsoi/Desktop/Lab/Conjugation/New_MATLAB/Simulation_Figures/
% set(gcf, 'PaperPositionMode', 'auto');
% print('DoS_3n2p_subpop','-dpng','-r300');
% close;

stack0 = sum(stacks(:,[1 5 9]),2);
stackC = sum(stacks(:,[3 4 7 8 11 12]),2);
stackD = sum(stacks(:,[2 4 6 8 10 12]),2);

figure()
g = plot(t, [stack0 stackC stackD]);
g(1).LineWidth = 1.5; 
g(2).LineWidth = 1.5; 
g(3).LineWidth = 1.5; 
set(gca, 'YScale', 'log' )
hold on
xline(0.75*t(end), 'Linewidth', 3, 'Color', 'k', 'LineStyle', '--');
hold off
xlim([0 t(end)])
ylim([0 1])
set(gca,'Xtick',[])
set(gca, 'Xticklabel', [])
set(gca,'Ytick',[])
set(gca, 'Yticklabel', [])
legend('0', 'C', 'D')

% cd /Users/ryantsoi/Desktop/Lab/Conjugation/New_MATLAB/Simulation_Figures/
% set(gcf, 'PaperPositionMode', 'auto');
% print('DoS_3n2p_plas','-dpng','-r300');
% close;


function dydt = DoS(Time,y,p) 
%% Parameters (based from Allie's model/supplementary) %%

%If density drops below 1 cell, then the population has died out completely 
y(y < 1e-9) = 0;
y=round(y,9);

%Growth rates and relative plasmid burdens%
umax = [0.3 0.2 0.25]; %Growth rate of resident and Top10 in hr-1
alphad = 1/1.21; %Natural burden of DoS plasmid
alphaf = 1/0.81; %Natural burden of conjugative plasmid
K = 1; %Carrying capacity

%Antibiotic (linear)
burden = 1-p{2}; %Degree of Cm suppression of growth 
benefit = 1+p{2};  %Degree of Cm growth benefit 

% %Antibiotic (hill)
% Km = 0.5;
% n = 1;
% burden = Km^n/(Km^n + p{2}^n); %Degree of Cm suppression of growth 
% benefit = p{2}^n/(Km^n + p{2}^n);  %Degree of Cm growth benefit 

%Dilution
D = p{1}; %Allie number is 0.05
%D = 0.05 --> %Dilution rate in Hr-1 (reflects 10^4 daily dilution fold)
subpop = p{5};

% Conditional growth rate and inducible cutting based on different phases
% (remember to switch around based on order of equations)
if Time <= 0.75*p{4} && p{2} > 0
    u = [ umax(1)*burden ... %MG1655 empty
    umax(1)*alphad*benefit ... %MG1655 DoS
    umax(1)*alphaf*burden ... %MG1655 C
    umax(1)*alphad*alphaf*benefit ... %MG1655 C + DoS
    
    umax(2)*burden ... %Top10 empty
    umax(2)*alphad*benefit ... %Top10 DoS
    umax(2)*alphaf*burden ... %Top10 C
    umax(2)*alphad*alphaf*benefit ... %Top10 C + DoS

    umax(3)*burden ... %J53 empty
    umax(3)*alphad*benefit ... %J53 DoS
    umax(3)*alphaf*burden ... %J53 C
    umax(3)*alphad*alphaf*benefit]; %J53 C + DoS

    ISceI = 0;

else
    u = [ umax(1) ... %MG1655 empty
    umax(1)*alphad ... %MG1655 DoS
    umax(1)*alphaf ... %MG1655 C
    umax(1)*alphad*alphaf ... %MG1655 C + DoS
    
    umax(2) ... %Top10 empty
    umax(2)*alphad ... %Top10 DoS
    umax(2)*alphaf ... %Top10 C
    umax(2)*alphad*alphaf... %Top10 C + DoS

    umax(3) ... %J53 empty
    umax(3)*alphad ... %J53 DoS
    umax(3)*alphaf ... %J53 C
    umax(3)*alphad*alphaf]; %J53 C + DoS

    ISceI = p{3};
end

% Segregation error%
sigmaD = 1e-4; %Segregation error of DoS
sigmaF = 1e-4; %Segregation error of conjugative plasmid
    
% Conjugation rates%
etaF0 = 1.76e-3; %Allie's number for RP4

%Cotransfer/Retrotransfer
etaF1 = etaF0/10; %Conjugation of conjugative plasmid (suppressed by DoS)
etaD = etaF0; %Conjugation of DoS becomes the same as base number from experimental data
etaB = etaF0/100; %Conjugation of both plasmids
etaRet = etaF0/100; %1% of all conjugation events become retrotransfer (hence the observed 100-fold slower)

gamma = umax; %Incompatibility (the same rate as growth)

%% ODEs %%
%This is a full model of the long term experiments 

%M_0: empty cells%
dydt(1,1) = u(1)*y(1)*(1-sum(y(subpop(:,1) == 1 | subpop(:,1) == 2))/K)...
    - etaF0*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... 
    - (etaF1+etaD+etaB)*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + sigmaF*y(2) + (sigmaD+ISceI)*y(2) - D*y(1);
%M_D%
dydt(2,1) = u(2)*y(2)*(1-sum(y(subpop(:,1) == 1 | subpop(:,1) == 2))/K)...
    + etaD*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    - etaF0*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))...
    - etaF1*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    - etaRet*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... %_F + MD
    + gamma(1)*y(4) - (sigmaD+ISceI+D)*y(2);
%M_F%
dydt(3,1) = u(3)*y(3)*(1-sum(y(subpop(:,1) == 1 | subpop(:,1) == 2))/K)...
    + etaF0*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... 
    + etaF1*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... 
    - etaRet*y(3)*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))... %MF + _D
    + (gamma(1)+ISceI)*y(4) - (sigmaF+D)*y(3);
%M_FD%
dydt(4,1) = u(4)*y(4)*(1-sum(y(subpop(:,1) == 1 | subpop(:,1) == 2))/K)...
    + etaF0*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))...
    + etaF1*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + etaB*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(3)... %MF + (MD/TD)
    + etaRet*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... %(TF/MF) + MD
    - (gamma(1)+ISceI+D)*y(4);

%T_0: empty cells%
dydt(5,1) = u(5)*y(5)*(1-sum(y)/K)...
    - etaF0*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... 
    - (etaF1+etaD+etaB)*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + sigmaF*y(6) + (sigmaD+ISceI)*y(6) - D*y(5);
%T_D%
dydt(6,1) = u(6)*y(6)*(1-sum(y)/K)...
    + etaD*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    - etaF0*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))...
    - etaF1*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    - etaRet*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... %_F + MD
    + gamma(1)*y(8) - (sigmaD+ISceI+D)*y(6);
%T_F%
dydt(7,1) = u(7)*y(7)*(1-sum(y)/K)...
    + etaF0*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... 
    + etaF1*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... 
    - etaRet*y(7)*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))... %TF + _D
    + (gamma(1)+ISceI)*y(8) - (sigmaF+D)*y(7);
%T_FD%
dydt(8,1) = u(8)*y(8)*(1-sum(y)/K)...
    + etaF0*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))...
    + etaF1*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + etaB*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(7)... %MF + (MD/TD)
    + etaRet*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... %(TF/MF) + MD
    - (gamma(1)+ISceI+D)*y(8);

%J_0: empty cells%
dydt(9,1) = u(9)*y(9)*(1-sum(y(subpop(:,1) == 2 | subpop(:,1) == 3))/K)...
    - etaF0*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... 
    - (etaF1+etaD+etaB)*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + sigmaF*y(10) + (sigmaD+ISceI)*y(10) - D*y(9);
%J_D%
dydt(10,1) = u(10)*y(10)*(1-sum(y(subpop(:,1) == 2 | subpop(:,1) == 3))/K)...
    + etaD*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    - etaF0*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))...
    - etaF1*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    - etaRet*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... %_F + MD
    + gamma(1)*y(12) - (sigmaD+ISceI+D)*y(10);
%J_F%
dydt(11,1) = u(11)*y(11)*(1-sum(y(subpop(:,1) == 2 | subpop(:,1) == 3))/K)...
    + etaF0*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... 
    + etaF1*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... 
    - etaRet*y(11)*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))... %TF + _D
    + (gamma(1)+ISceI)*y(12) - (sigmaF+D)*y(11);
%J_FD%
dydt(12,1) = u(12)*y(12)*(1-sum(y(subpop(:,1) == 2 | subpop(:,1) == 3))/K)...
    + etaF0*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))...
    + etaF1*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + etaB*y(9)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(11)... %MF + (MD/TD)
    + etaRet*y(10)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... %(TF/MF) + MD
    - (gamma(1)+ISceI+D)*y(12);
