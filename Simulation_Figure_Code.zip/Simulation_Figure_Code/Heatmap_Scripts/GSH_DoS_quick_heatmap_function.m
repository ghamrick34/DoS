function GSH_DoS_quick_heatmap_function(etaF0,alphad,alphaf)
    N0 = 1e-6;
    R = 1;
    D = 0.05; %Range of dilution rates (0 dilution means no passaging)
    Cm = 0.5; %Antibiotic inhibition. 0 is no inhibition (Top10 always loses), 1 is complete inhibition (Top10 always win)
    ISceI = 0;
    time = 1200; %Simulation time (time units are hours
    umax_R = linspace(0.1,0.6,50);
    umax_T = linspace(0.1,0.5,50);
    t_treatment = zeros(length(umax_R), length(umax_T));
    
    %Growth rates and relative plasmid burdens%
    umax = [0.3 0.2]; %Growth rate of resident and Top10 in hr-1
    
    for i = 1:length(umax_R)
        disp(i)
        umax(1) = umax_R(i);
        for j = 1:length(umax_T)
            umax(2) = umax_T(j);
        
            [t,y] = GSH_DoS_2n2p(N0, R, D, Cm, ISceI, time, umax, alphad, alphaf, etaF0);
            
            %% Output t-critical %%
            %The critical treatment time is the first point at which the fraction of cells
            %with the conjugative plasmid hits 0 (falls below 1e-9 in simulation) and
            %the resident population is >0. Otherwise, the treatment time is set 
            %to the simulation time (maximum).
            
            y(y < 1e-9) = 0; %Any fraction less than 1e-9 is less than a cell (how the code was implemented)
            RP4 = sum(y(:,[3 4 7 8]), 2); %number of cells with conjugative plasmid
            f_M = sum(y(:,1:4), 2);
            f_T =  sum(y(:,5:8), 2);
            
            temp = find(RP4 == 0);
           
            if f_M(end) < f_T(end) || f_M(end) == 0 
                t_treatment(length(umax_R)+1-i,j) = time;
            elseif isempty(temp) || all(RP4(end-5:end)>0)
                t_treatment(length(umax_R)+1-i,j) = time;
            else
                t_treatment(length(umax_R)+1-i,j) = t(temp(1));
            end
        end
    end
    
    
    
    %Log scale data
    t_treatment_days = t_treatment/24;
    
    file_name = "etaF_"+etaF0+"_alphad_"+alphad+"_alphaf_"+alphaf+"_"+length(umax_R)+"x"+length(umax_T);
    save('./matrices/'+file_name+".mat","t_treatment_days");
    
    
    imagesc(t_treatment_days);
    colormap(flipud(parula))
    clim([15, time/24]);
    colorbar
    %y axis is dilution rate
    %x axis is antibiotic concentration
    set(gca, 'Xticklabel', [])
    set(gca, 'Yticklabel', [])
    
    
    xlabel('\mu_T (hr^{-1})','FontSize',20); % Set the label for the x-axis
    ylabel('\mu_R (hr^{-1})','FontSize',20); % Set the label for the y-axis
    
    xticks([1 length(umax_T)]); % Set tick positions for x-axis
    xticklabels({'0.1', '0.5'}); % Set tick labels for x-axis
    
    yticks([1 length(umax_R)]); % Set tick positions for y-axis
    yticklabels({'0.6', '0.1'}); % Set tick labels for y-axis
    
    ax = gca; % Get current axes
    ax.FontSize = 20; % Set font size for ticks
    
    
    set(gcf, 'PaperPositionMode', 'auto');
    %print(file_name+'_heatmap','-dpng','-r300');
    folder_name = './heatmaps/';
    exportgraphics(gcf, folder_name+file_name+'_heatmap.eps', 'Resolution', 300);
    exportgraphics(gcf, folder_name+file_name+'_heatmap.tif', 'Resolution', 300);
    %close;