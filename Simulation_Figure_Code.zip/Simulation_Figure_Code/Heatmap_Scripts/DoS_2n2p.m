function [t,y] = DoS_2n2p(N0, ratio, dilution, antibiotic, ISceI, time)
%N0 is the starting density of the total community
%Ratio is the starting ratio of the resident population to the DoS population
%D is the dilution rate
%Ant concentration of Cm betweeen 0-1 (higher Cm means more growth suppression)
%ISceI is the level of aTc induction
%time is the simulation time

% [t,y] = DoS_2n2p(1e-2, 100, 0.05, 0.6, 0.01, 3e3); %Single time course
% matching experimental data

%% Making the permutations of the different combinations of plasmids
num_plas = 2;
pop = 2;
temp = zeros(1,num_plas);
indexes = zeros(1,num_plas);

for i = 1:num_plas
    temp(1:i) = 1;
    permutation = unique(perms(temp), 'rows');
    indexes = [indexes; permutation];
end
 
%Duplicate and append a column designating which population
indexes = repmat(indexes, pop, 1);
pop_col = zeros(pop*2^num_plas,1);
pop_col(size(pop_col)/2+1:end,1) = 1;

subpop = [pop_col indexes];

%% ODE parameters and running %%
%If changing order of equations, change this too
tspan = [0 time]; %units in Hr
y0 = [0; %MG1655
    0; %MG1655 DoS
    N0; %MG1655 RP4
    0; %MG1655 conjugative plasmid DoS
    0; %Top10
    N0/ratio; %Top10 DoS
    0; %Top10 RP4
    0]; %Top10 conjugative plasmid DoS
parameters = {dilution antibiotic ISceI time subpop};
options = odeset('NonNegative',[1:8]);

[t,y] = ode45(@(t,y) DoS(t,y,parameters), tspan, y0, options);


y(y < 1e-9) = 0; %Any fraction less than 1e-9 is less than a cell (how the code was implemented)
stacks= y ./sum(y,2); %Changing the time courses to fractional populations

%% Plotting %%

y(y < 1e-9) = 0; %Any fraction less than 1e-9 is less than a cell (how the code was implemented)
stacks= y ./sum(y,2); %Changing the time courses to fractional populations

%%%% Subpopulation fractions %%%%
figure()
%g = area(t, stacks);
g = plot(t,stacks(:,  [ 1 3 2 4 5 7 6 8 ]), 'LineWidth', 3);
hold on
xline(0.6*t(end), 'Linewidth', 2, 'Color', 'k', 'LineStyle', '--');
hold off

linecolors = [88 204 237 ;
    56 149 211 ;
    18 97 160 ;
    7 47 95 ;
    248 237 98 ;
    233 215 0 ;
    218 182 0 ;
    169 134 0]/255;

for i = 1:8
    g(i).Color = linecolors(i,:);
end

xlim([0 t(end)])
ylim([0 1])
set(gca,'Xtick',[])
set(gca, 'Xticklabel', [])
set(gca,'Ytick',[])
set(gca, 'Yticklabel', [])
set(gca,'Box','on');

% Set image size
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) 500 250]); %<- Set size
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1) - 5)/2;
bottom = (papersize(2) - 2.5)/2;
myfiguresize = [left, bottom, 5, 2.5];
set(gcf,'PaperPosition', myfiguresize);

% cd /Users/ryantsoi/Desktop/Lab/Conjugation/New_MATLAB/Simulation_Figures/
print('DoS_2n2p_subpop','-dpng','-r300');
close;

stack0 = sum(stacks(:,[1 5]),2);
stackC = sum(stacks(:,[3 4 7 8]),2);
stackD = sum(stacks(:,[2 4 6 8]),2);
stackM = sum(stacks(:,1:4),2)';
stackT = sum(stacks(:,5:8),2)';

figure()
a = area(t,[stackM' stackT']);
a(1).FaceColor = [224 235 246]/255;
a(2).FaceColor = [252 242 208]/255;
a(1).EdgeColor = [224 235 246]/255;
a(2).EdgeColor = [252 242 208]/255;
hold on;
g = plot(t, [stack0 stackC stackD], 'LineWidth', 3);
g(1).Color = [85 85 85]/255; 
g(2).Color = [0 153 0]/255; 
g(3).Color = [153 0 0]/255; 
xline(0.6*t(end), 'Linewidth', 2, 'Color', 'k', 'LineStyle', '--');
hold off
xlim([0 t(end)])
ylim([0 1])
set(gca,'Xtick',[])
set(gca, 'Xticklabel', [])
set(gca,'Ytick',[])
set(gca, 'Yticklabel', [])
set(gca,'Box','on');

% Set image size
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) 500 250]); %<- Set size
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1) - 5)/2;
bottom = (papersize(2) - 2.5)/2;
myfiguresize = [left, bottom, 5, 2.5];
set(gcf,'PaperPosition', myfiguresize);

% cd /Users/ryantsoi/Desktop/Lab/Conjugation/New_MATLAB/Simulation_Figures/
print('DoS_2n2p_plas','-dpng','-r300');



function dydt = DoS(Time,y,p) 
%% Parameters (based from Allie's model/supplementary) %%

%If density drops below 1 cell, then the population has died out completely 
y(y < 1e-9) = 0;
y=round(y,9);

%Growth rates and relative plasmid burdens%
umax = [0.3 0.2]; %Growth rate of resident and Top10 in hr-1
alphad = 1/1.21; %Natural burden of DoS plasmid
alphaf = 1/0.81; %Natural burden of conjugative plasmid
K = 1; %Carrying capacity

%Antibiotic (linear)
burden = 1-p{2}; %Degree of Cm suppression of growth 
benefit = 1+p{2};  %Degree of Cm growth benefit 

% %Antibiotic (hill)
% Km = 0.5;
% n = 1;
% burden = Km^n/(Km^n + p{2}^n); %Degree of Cm suppression of growth 
% benefit = p{2}^n/(Km^n + p{2}^n);  %Degree of Cm growth benefit 

%Dilution
D = p{1}; %Allie number is 0.05
%D = 0.05 --> %Dilution rate in Hr-1 (reflects 10^4 daily dilution fold)
subpop = p{5};

% Conditional growth rate and inducible cutting based on different phases
% (remember to switch around based on order of equations)
if Time <= 0.6*p{4} && p{2} > 0
    u = [ umax(1)*burden ... %MG1655 empty
    umax(1)*alphad*benefit ... %MG1655 DoS
    umax(1)*alphaf*burden ... %MG1655 C
    umax(1)*alphad*alphaf*benefit ... %MG1655 C + DoS
    umax(2)*burden ... %Top10 empty
    umax(2)*alphad*benefit ... %Top10 DoS
    umax(2)*alphaf*burden ... %Top10 C
    umax(2)*alphad*alphaf*benefit]; %Top10 C + DoS

    ISceI = 0;

else
    u = [ umax(1) ... %MG1655 empty
    umax(1)*alphad ... %MG1655 DoS
    umax(1)*alphaf ... %MG1655 C
    umax(1)*alphad*alphaf ... %MG1655 C + DoS
    umax(2) ... %Top10 empty
    umax(2)*alphad ... %Top10 DoS
    umax(2)*alphaf ... %Top10 C
    umax(2)*alphad*alphaf]; %Top10 C + DoS

    ISceI = p{3};
end

% Segregation error%
sigmaD = 1e-4; %Segregation error of DoS
sigmaF = 1e-4; %Segregation error of conjugative plasmid
    
% Conjugation rates%
etaF0 = 1.76e-3; %Allie's number for RP4

%Cotransfer/Retrotransfer
etaF1 = etaF0/10; %Conjugation of conjugative plasmid (suppressed by DoS)
etaD = etaF0; %Conjugation of DoS becomes the same as base number from experimental data
etaB = etaF0/100; %Conjugation of both plasmids
etaRet = etaF0/100; %1% of all conjugation events become retrotransfer (hence the observed 100-fold slower)

gamma = umax; %Incompatibility (the same rate as growth)

%% ODEs %%
%This is a full model of the long term experiments 

%M_0: empty cells%
dydt(1,1) = u(1)*y(1)*(1-sum(y)/K)...
    - etaF0*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... 
    - (etaF1+etaD+etaB)*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + sigmaF*y(2) + (sigmaD+ISceI)*y(2) - D*y(1);
%M_D%
dydt(2,1) = u(2)*y(2)*(1-sum(y)/K)...
    + etaD*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    - etaF0*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))...
    - etaF1*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    - etaRet*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... %_F + MD
    + gamma(1)*y(4) - (sigmaD+ISceI+D)*y(2);
%M_F%
dydt(3,1) = u(3)*y(3)*(1-sum(y)/K)...
    + etaF0*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... 
    + etaF1*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... 
    - etaRet*y(3)*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))... %MF + _D
    + (gamma(1)+ISceI)*y(4) - (sigmaF+D)*y(3);
%M_FD%
dydt(4,1) = u(4)*y(4)*(1-sum(y)/K)...
    + etaF0*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))...
    + etaF1*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + etaB*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(3)... %MF + (MD/TD)
    + etaRet*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... %(TF/MF) + MD
    - (gamma(1)+ISceI+D)*y(4);

%T_0: empty cells%
dydt(5,1) = u(5)*y(5)*(1-sum(y)/K)...
    - etaF0*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... 
    - (etaF1+etaD+etaB)*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + sigmaF*y(6) + (sigmaD+ISceI)*y(6) - D*y(5);
%T_D%
dydt(6,1) = u(6)*y(6)*(1-sum(y)/K)...
    + etaD*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    - etaF0*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))...
    - etaF1*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    - etaRet*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... %_F + MD
    + gamma(1)*y(8) - (sigmaD+ISceI+D)*y(6);
%T_F%
dydt(7,1) = u(7)*y(7)*(1-sum(y)/K)...
    + etaF0*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... 
    + etaF1*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... 
    - etaRet*y(7)*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))... %TF + _D
    + (gamma(1)+ISceI)*y(8) - (sigmaF+D)*y(7);
%T_FD%
dydt(8,1) = u(8)*y(8)*(1-sum(y)/K)...
    + etaF0*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))...
    + etaF1*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + etaB*y(5)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))...
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(7)... %MF + (MD/TD)
    + etaRet*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... %(TF/MF) + MD
    - (gamma(1)+ISceI+D)*y(8);

% %M_0: empty cells%
% dydt(1,1) = u(1)*y(1)*(1-sum(y)/K) - etaF0*(y(6)+y(2))*y(1) - (etaF1+etaD+etaB)*(y(8)+y(4))*y(1) + sigmaF*y(2) + (sigmaD+ISceI)*y(3) - D*y(1);
% %M_F: empty cells%
% dydt(2,1) = u(2)*y(2)*(1-sum(y)/K) + etaF0*(y(6)+y(2))*y(1) + etaF1*(y(8)+y(4))*y(1) - etaRet*y(2)*(y(3)+y(7)) + (gamma(1)+ISceI)*y(4) - (sigmaF+D)*y(2);
% %M_D: empty cells%
% dydt(3,1) = u(3)*y(3)*(1-sum(y)/K) - etaF0*(y(6)+y(2))*y(3) + (y(8)+y(4))*(etaD*y(1)-etaF1*y(3)) - etaRet*(y(6)+y(2))*y(3) + gamma(1)*y(4) - (sigmaD+ISceI+D)*y(3);
% %M_FD: empty cells%
% dydt(4,1) = u(4)*y(4)*(1-sum(y)/K) + etaF0*(y(6)+y(2))*y(3) + (y(8)+y(4))*(etaF1*y(3)+etaB*y(1)) + etaRet*(2*y(2)*y(3)+y(6)*y(3)+y(2)*y(7)) - (gamma(1)+ISceI+D)*y(4);
% %T_0: empty cells%
% dydt(5,1) = u(5)*y(5)*(1-sum(y)/K) - etaF0*(y(6)+y(2))*y(5) - (etaF1+etaD+etaB)*(y(8)+y(4))*y(5) + sigmaF*y(6) + (sigmaD+ISceI)*y(7) - D*y(5);
% %T_F: empty cells%
% dydt(6,1) = u(6)*y(6)*(1-sum(y)/K) + etaF0*(y(6)+y(2))*y(5) + etaF1*(y(8)+y(4))*y(5) - etaRet*y(6)*(y(3)+y(7))+ (gamma(2)+ISceI)*y(8) - (sigmaF+D)*y(6);
% %T_D: empty cells%
% dydt(7,1) = u(7)*y(7)*(1-sum(y)/K) - etaF0*(y(6)+y(2))*y(7) + (y(8)+y(4))*(etaD*y(5)-etaF1*y(7)) - etaRet*(y(6)+y(2))*y(7) + gamma(2)*y(8) - (sigmaD+ISceI+D)*y(7);
% %T_FD: empty cells%
% dydt(8,1) = u(8)*y(8)*(1-sum(y)/K) + etaF0*(y(6)+y(2))*y(7) + (y(8)+y(4))*(etaF1*y(7)+etaB*y(5))  + etaRet*(2*y(6)*y(7)+y(2)*y(7)+y(6)*y(3)) - (gamma(2)+ISceI+D)*y(8);

