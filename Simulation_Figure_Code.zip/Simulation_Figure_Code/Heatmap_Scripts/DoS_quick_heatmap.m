densities = 1e-6; %Range of starting densities from 10^4 to 10^7 cells. 
ratios = 1; %Range of starting ratios (Resident:DoS) from 1:1 to 1000:1
dilutions = linspace(0,0.23,5); %Range of dilution rates (0 dilution means no passaging)
Cm = linspace(0,1,5); %Antibiotic inhibition. 0 is no inhibition (Top10 always loses), 1 is complete inhibition (Top10 always win)

N0 = densities;
R = ratios;
ISceI = 0;
time = 1e4; %Simulation time (time units are hours
t_treatment = zeros(length(densities), length(ratios));

for i = 1:length(dilutions)
    disp(i)
    D = dilutions(i);
    for j = 1:length(Cm)
        Ant = Cm(j);
    
        [t,y] = DoS_2n2p(N0, R, D, Ant, ISceI, time);
        
        %% Output t-critical %%
        %The critical treatment time is the first point at which the fraction of cells
        %with the conjugative plasmid hits 0 (falls below 1e-9 in simulation) and
        %the resident population is >0. Otherwise, the treatment time is set 
        %to the simulation time (maximum).
        
        y(y < 1e-9) = 0; %Any fraction less than 1e-9 is less than a cell (how the code was implemented)
        RP4 = sum(y(:,[3 4 7 8]), 2); %number of cells with conjugative plasmid
        f_M = sum(y(:,1:4), 2);
        f_T =  sum(y(:,5:8), 2);
        
        temp = find(RP4 == 0);
       
        if f_M(end) < f_T(end) || f_M(end) == 0 
            t_treatment(i,j) = time;
        elseif isempty(temp) || all(RP4(end-5:end)>0)
            t_treatment(i,j) = time;
        else
            t_treatment(i,j) = t(temp(1));
        end
    end
end

% save('HM_1e-6_1_51x51.mat');

%Log scale data
t_treatment_days = t_treatment/24;
heatmap = imagesc(t_treatment_days);
colormap(flipud(parula))
colorbar
%y axis is dilution rate
%x axis is antibiotic concentration
set(gca, 'Xticklabel', [])
set(gca, 'Yticklabel', [])

set(gcf, 'PaperPositionMode', 'auto');
print('DoS_heatmap','-dpng','-r300');
close;