etaF0_range = [1e-4 1e-3 1e-2];
alphad_range = [0.6 0.8 1.0];
alphaf_range = [0.6 0.9 1.2];

for etaF0 = etaF0_range
    alphad = 0.7692; %Natural burden of DoS plasmid
    alphaf = 1.1111; %Natural burden of conjugative plasmid
    
    GSH_DoS_quick_heatmap_function(etaF0,alphad,alphaf)

end

for alphad = alphad_range
    etaF0 = 1.76e-3; %Natural burden of DoS plasmid
    alphaf = 1.1111; %Natural burden of conjugative plasmid
    
    GSH_DoS_quick_heatmap_function(etaF0,alphad,alphaf)

end

for alphaf = alphaf_range
    etaF0 = 1.76e-3; %Natural burden of DoS plasmid
    alphad = 0.7692; %Natural burden of conjugative plasmid
    
    GSH_DoS_quick_heatmap_function(etaF0,alphad,alphaf)

end