function [t, y, stackM, stackT, stacksC, stacksD, parameters] = Any_DoS_community(n, p, N0, ratio, dilution, antibiotic, interval_C, interval_D, ISceI, time)
%For now we assume exactly 1 DoS plasmid for every conjugative plasmid, and
%only 2 strains
rng(1)

%[t, y, stacks0, stacksC, stacksD, parameters] = Any_DoS_community(2, 6, 1e-6, 1, 0.05, 0.9, 0, 1e5);
%If conjugative plasmids are burdensome, then only the best DoS plasmid survives
%If the conjugative plasmids are beneficial, then the best combination of 1 DoS plasmid and remaining orthogonal conjugative plasmids survives
%% Making the permutations of the different combinations of plasmids
temp = zeros(1,p);
ind = zeros(1,p);

for i = 1:p
    temp(1:i) = 1;
    perm = unique(perms(temp), 'rows');
    ind = [ind; perm];
end
 
%Duplicate and append a column designating which population
ind = repmat(ind, n, 1);
pop_col = zeros(n*2^p,1);
pop_col(size(pop_col)/n+1:end,1) = 1;

subpop = [pop_col ind];

%% All parameters

%Plasmid burden/benefit
%interval_C = [0.9 1.0];
%interval_D = [0.8 0.9];
alphaC = interval_C(1) + (interval_C(2)-interval_C(1)).*rand(1,p/2); 
alphaD = interval_D(1) + (interval_D(2)-interval_D(1)).*rand(1,p/2);

%Strain growth rate
interval_M = [0.3 0.33];
gM = interval_M(1) + (interval_M(2)-interval_M(1)).*rand(1); 
interval_T = [0.7 0.9];
gT = interval_T(1) + (interval_T(2)-interval_T(1)).*rand(1); 
mu = [gM gT*gM];

%Carrying capacity
K = 1; 

%Antibioticinduced burden/benefit
burden = 1-antibiotic; %Degree of Cm suppression of growth
benefit = 1+antibiotic;  %Degree of Cm growth benefit

%Growth matrix%
growth = [];
for i = 1:n
    growth = [growth repmat(mu(i), 1, 2^p)];
end
u = ones(1,size(subpop,1));

%Growth matrix
for j = 1:size(u,2)
    plasmids = prod([alphaC.^subpop(j,2:(1+p/2)) alphaD.^subpop(j,(2+p/2):end)]);
    if sum(subpop(j,(2+p/2):end)) >= 1
        ant = benefit;
    else
        ant = burden;
    end
    u(j) = growth(j)*plasmids*ant;
end

% Conjugation rates%
interval_C0 = [1 2].*1e-2;
etaC0 = interval_C0(1) + (interval_C0(2)-interval_C0(1)).*rand(1,p/2); 

%Cotransfer/Retrotransfer
etaC1 = etaC0./10; %Conjugation of conjugative plasmid (suppressed by DoS)
etaD = etaC0; %Conjugation of DoS becomes the same as base number from experimental data
etaB = etaC0./100; %Conjugation of both plasmids
etaRet = etaC0./100; %1% of all conjugation events become retrotransfer (hence the observed 100-fold slower)

%Segregation error
interval_seg = [1 2].*1e-3;
sigmaD = interval_seg(1) + (interval_seg(2)-interval_seg(1)).*rand(1,p/2); %Segregation error of DoS
sigmaC = 0.01*(interval_seg(1) + (interval_seg(2)-interval_seg(1)).*rand(1,p/2)); %Segregation error of conjugative plasmid
iscei = ISceI;

%Incompatibility (the same rate as growth)
gamma = mu;

%% ODE parameters and initialization %%
y0 = zeros(size(subpop,1),1);
for a = 1:size(y0,1)
    if subpop(a,1) == 0 && nnz(subpop(a,2:(1+p/2))) == 1 && nnz(subpop(a,(2+p/2):end)) == 0
        y0(a) = N0;
    elseif subpop(a,1) == 1 && nnz(subpop(a,2:(1+p/2))) == 0 && nnz(subpop(a,(2+p/2):end)) == 1
        y0(a) = N0/ratio;
    else
        y0(a) = 0;
    end
end

parameters = {subpop n p u K dilution etaC0 etaC1 etaD etaB etaRet sigmaD sigmaC gamma iscei alphaC alphaD};

tspan = [0 time]; %units in Hr
options = odeset('NonNegative',[1:size(subpop,1)]);

[t,y] = ode45(@(t,y) DoS(t,y,parameters), tspan, y0, options);

y(y < 1e-9) = 0; %Any fraction less than 1e-9 is less than a cell (how the code was implemented)
stacks= y ./sum(y,2); %Changing the time courses to fractional populations

%Separating the populations

stackM = sum(stacks(:,1:size(subpop,1)/2),2);
stackT = sum(stacks(:,(size(subpop,1)/2+1):end),2);

for b = 2:(1+p/2)
    stacksC{b-1} = sum(stacks(:,any(subpop(:,b),2)),2);
    stacksD{b-1} = sum(stacks(:,any(subpop(:,b+p/2),2)),2);
end

%% Plotting %%

% figure()
% g = area(t, [stackM stackT]);
% g(1).FaceColor= [211 211 211]/255;
% g(2).FaceColor= [110 110 110]/255;
% hold on
% plot(t, [stacksC{:} stacksD{:}], 'Linewidth', 3);
% % hold on
% % xline(0.75*t(end), 'Linewidth', 3, 'Color', 'k', 'LineStyle', '--');
% % hold off
% legendCell = num2cell(['M', 'T', strcat('C',string(num2cell(1:p/2))), strcat('D',string(num2cell(1:p/2)))]);
% legend(legendCell)
% % xlim([0 t(10000)])
% % ylim([0 1])
% % % set(gca,'Xtick',[])
% % % set(gca, 'Xticklabel', [])
% % % set(gca,'Ytick',[])
% % % set(gca, 'Yticklabel', [])
% set(gca, 'YScale', 'log')

% % cd /Users/ryantsoi/Desktop/Lab/Conjugation/New_MATLAB/Simulation_Figures/
% % set(gcf, 'PaperPositionMode', 'auto');
% % print('DoS_2n2p_plas','-dpng','-r300');
% % close;

function dydt = DoS(Time,y,parameters) 

%% If density drops below 1 cell, then the population has died out completely 
y(y < 1e-9) = 0;

%% Making dydt

subpop = parameters{1};
n = parameters{2};
p = parameters{3};
u = parameters{4};
K = parameters{5};
dilution = parameters{6};
etaC0 = parameters{7};
etaC1 = parameters{8};
etaD = parameters{9};
etaB = parameters{10};
etaRet = parameters{11};
sigmaD = parameters{12};
sigmaC = parameters{13};
gamma = parameters{14};
iscei = parameters{15};

dydt = zeros(size(subpop,1),1);

for i = 1:size(subpop,1)
    CONJUGATION = 0;
    COTRANSFER = 0;
    RETROTRANSFER = 0;
    SEGREGATION = 0;
    ISCE1 = 0;
    
    index = subpop(i,:);
    for j = 2:(p/2+1)
        temp = index;
        
        %First index to indicate no plasmid
        temp(j) = 0;
        temp(j+p/2) = 0;
        ind0 = ismember(subpop,temp,'rows');
        %Second index to indicate only the C population
        temp(j) = 1; 
        temp(j+p/2) = 0;
        indC = ismember(subpop,temp,'rows');
        %Second index to indicate only the D population
        temp(j) = 0;
        temp(j+p/2) = 1;
        indD = ismember(subpop,temp,'rows');
        %final index to indicate both
        temp(j) = 1;
        temp(j+p/2) = 1;
        indCD = ismember(subpop,temp,'rows');
            
        if index(j) == 1 && index(j+p/2) == 1 %C1+D1
            CONJUGATION = CONJUGATION + etaC0(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 0))*y(indD) + etaC1(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 1))*y(indD); 
            COTRANSFER = COTRANSFER + etaB(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 1))*y(ind0);
            RETROTRANSFER = RETROTRANSFER + etaRet(j-1)*y(indC)*sum(y(subpop(:,j) == 0 & subpop(:,j+p/2) == 1)) + etaRet(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 0))*y(indD);
            SEGREGATION = SEGREGATION - gamma(temp(1)+1)*y(i);
            ISCE1 = ISCE1 - iscei*y(i);
        
        elseif index(j) == 1 && index(j+p/2) == 0  %C1 only        
            CONJUGATION = CONJUGATION +  etaC0(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 0))*y(ind0) +  etaC1(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 1))*y(ind0);
            COTRANSFER = COTRANSFER;
            RETROTRANSFER = RETROTRANSFER - etaRet(j-1)*y(i)*sum(y(subpop(:,j) == 0 & subpop(:,j+p/2) == 1));
            SEGREGATION = SEGREGATION + gamma(temp(1)+1)*y(indCD) - sigmaC(j-1)*y(i);
            ISCE1 = ISCE1 + iscei*y(indCD);
        
        elseif index(j) == 0 && index(j+p/2) == 1  %D1 only
            CONJUGATION = CONJUGATION - etaC0(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 0))*y(i) - etaC1(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 1))*y(i) + etaD(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 1))*y(ind0);
            COTRANSFER = COTRANSFER;
            RETROTRANSFER = RETROTRANSFER - etaRet(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 0))*y(i);
            SEGREGATION = SEGREGATION + gamma(temp(1)+1)*y(indCD) - sigmaD(j-1)*y(i);
            ISCE1 = ISCE1 - iscei*y(i);
       
        else %No plasmid
            CONJUGATION = CONJUGATION - etaC0(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 0))*y(i) - etaC1(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 1))*y(i) - etaD(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 1))*y(i);
            COTRANSFER = COTRANSFER - etaB(j-1)*sum(y(subpop(:,j) == 1 & subpop(:,j+p/2) == 1))*y(i);
            RETROTRANSFER = RETROTRANSFER;
            SEGREGATION = SEGREGATION + sigmaC(j-1)*y(indC) + sigmaD(j-1)*y(indD);
            ISCE1 = ISCE1 + iscei*y(indD);
        end
    end
    
    GROWTH = u(i)*y(i)*(1-sum(y)/K);
    DEATH = -dilution*y(i);
    dydt(i,1) = GROWTH + CONJUGATION + COTRANSFER + RETROTRANSFER + SEGREGATION + ISCE1 + DEATH;
    
end
