%% Sequential treatment script %%

%% First treatment

num_plas = 3;
pop = 2;
temp = zeros(1,num_plas);
indexes = zeros(1,num_plas);

for i = 1:num_plas
    temp(1:i) = 1;
    permutation = unique(perms(temp), 'rows');
    indexes = [indexes; permutation];
end
 
%Duplicate and append a column designating which population
indexes = repmat(indexes, 2, 1);
pop_col = zeros(pop*2^num_plas,1);
pop_col(size(pop_col)/2+1:end,1) = 1;

subpop = [pop_col indexes];


[t1,y1] = DoS_2n3p(1e-2, 1e3, 0.05, 0.15, 0.1, 2e4); 
%[t,y] = DoS_2n3p(N0, ratio, dilution, antibiotic, ISceI, time)

y1(y1 < 1e-9) = 0; %Any fraction less than 1e-9 is less than a cell (how the code was implemented)
stacks1= y1 ./sum(y1,2); %Changing the time courses to fractional populations

stack01 = sum(stacks1(:,find(subpop(:,2) == 0 & subpop(:,3) == 0 & subpop(:,4) == 0)),2);
stackF1 = sum(stacks1(:, find(subpop(:,2) == 1)) ,2);
stackR1 = sum(stacks1(:, find(subpop(:,3) == 1)) ,2);
stackD1 = sum(stacks1(:, find(subpop(:,4) == 1)) ,2); 

%% Second treatment
[t2,y2] = DoS_2n2p(1e-2, 1, 0.05, 0.4, 0.01, 2e4); %Single time course

y2(y2 < 1e-9) = 0; %Any fraction less than 1e-9 is less than a cell (how the code was implemented)
stacks2= y2 ./sum(y2,2); %Changing the time courses to fractional populations

stack02 = sum(stacks2(:,[1 5]),2);
stackR2 = sum(stacks2(:,[3 4 7 8]),2);
stackD2 = sum(stacks2(:,[2 4 6 8]),2);

%Unifying the data
tfinal = [t1 ; t2+2e4];
stack0 = [stack01 ; stack02];
stackF = [stackF1 ; zeros(length(t2),1)];
stackR = [stackR1 ; stackR2];
stackDF = [stackD1 ; zeros(length(t2),1)];
stackDR = [ zeros(length(t1),1) ; stackD2];

%% Plotting %%

figure()
g = plot(tfinal, [stack0 stackF stackR stackDF stackDR], 'LineWidth', 3);
g(1).Color = [85 85 85]/255; 
g(2).Color = [0 153 0]/255; 
g(3).Color = [0 0 153]/255; 
g(4).Color = [153 0 0]/255; 
g(5).Color = [153 0 153]/255;
hold on
xline(0.375*tfinal(end), 'Linewidth', 2, 'Color', 'k', 'LineStyle', '--');
xline(0.5*tfinal(end), 'Linewidth', 2, 'Color', 'k', 'LineStyle', '--');
xline(0.875*tfinal(end), 'Linewidth', 2, 'Color', 'k', 'LineStyle', '--');
hold off
xlim([0 tfinal(end)])
ylim([0 1.2])
set(gca, 'Xticklabel', [])
set(gca, 'Yticklabel', [])

cd /Users/ryantsoi/Desktop/Lab/Conjugation/New_MATLAB/Simulation_Figures/
set(gcf, 'PaperPositionMode', 'auto');
print('Sequential_treatment','-dpng','-r300');
% close;