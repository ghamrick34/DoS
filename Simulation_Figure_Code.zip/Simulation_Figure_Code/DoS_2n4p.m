function [t,y] = DoS_2n4p(N0, ratio, dilution, antibiotic, ISceI, time)
%N0 is the starting density of the total community
%Ratio is the starting ratio of the resident population to the DoS population
%D is the dilution rate
%Ant concentration of Cm betweeen 0-1 (higher Cm means more growth suppression)
%ISceI is the level of aTc induction
%time is the simulation time

% [t,y] = DoS_2n4p(1e-6, 1, 0.05, 0.1, 0, 5e3); %Single time course

%% Making the permutations of the different combinations of plasmids
num_plas = 4;
pop = 2;
temp = zeros(1,num_plas);
indexes = zeros(1,num_plas);

for i = 1:num_plas
    temp(1:i) = 1;
    permutation = unique(perms(temp), 'rows');
    indexes = [indexes; permutation];
end
 
%Duplicate and append a column designating which population``
indexes = repmat(indexes, pop, 1);
pop_col = zeros(pop*2^num_plas,1);
pop_col(size(pop_col)/2+1:end,1) = 1;

subpop = [pop_col indexes];

%% ODE parameters %%

tspan = [0 time]; %units in Hr

%Initial condition
y0 = zeros(32,1);
y0(3) = N0;
y0(5) = N0;
y0(18) = N0/ratio;
y0(20) = N0/ratio;

parameters = {dilution antibiotic ISceI time subpop};
options = odeset('NonNegative',[1:32]);
[t,y] = ode45(@(t,y) DoS(t,y,parameters), tspan, y0, options);

%% Plotting %%

y(y < 1e-9) = 0; %Any fraction less than 1e-8 is less than a cell
stacks= y ./sum(y,2); %Changing the time courses to fractional populations

% figure()
% g = area(t, stacks);
% hold on
% % midline = line([time time], [0 1]);
% % set(midline, 'Linewidth', 3, 'Color', 'k', 'LineStyle', '--')
% hold off
% legend(cellstr(num2str(subpop)))
% xlim([0 t(end)])
% ylim([0 1])
% % set(gca, 'Xticklabel', [])
% % set(gca, 'Yticklabel', [])
% 
% % cd /Users/ryantsoi/Desktop/Lab/Conjugation/New_MATLAB/Simulation_Figures/
% % set(gcf, 'PaperPositionMode', 'auto');
% % print('DoS_2n4p_SP','-dpng','-r300');
% % close;

stack0 = sum(stacks(:,find(subpop(:,2) == 0 & subpop(:,3) == 0 & subpop(:,4) == 0 & subpop(:,5) == 0)),2);
stackF = sum(stacks(:, find(subpop(:,2) == 1)) ,2); 
stackR = sum(stacks(:, find(subpop(:,4) == 1)) ,2); 
stackDF = sum(stacks(:, find(subpop(:,3) == 1)) ,2); %Contains either DoS plasmid
stackDR = sum(stacks(:, find(subpop(:,5) == 1)) ,2); %Contains either DoS plasmid

figure()
g = plot(t, [stack0 stackF stackR stackDF stackDR], 'LineWidth', 3);
g(1).Color = [85 85 85]/255; 
g(2).Color = [0 153 0]/255; 
g(3).Color = [0 0 153]/255; 
g(4).Color = [153 0 0]/255; 
g(5).Color = [153 0 153]/255; 
hold on
xline(0.75*t(end), 'Linewidth', 2, 'Color', 'k', 'LineStyle', '--');
hold off
xlim([0 t(end)])
ylim([0 1.2])
set(gca, 'Xticklabel', [])
set(gca, 'Yticklabel', [])
set(gca,'Box','on');

cd /Users/ryantsoi/Desktop/Lab/Conjugation/New_MATLAB/Simulation_Figures/
set(gcf, 'PaperPositionMode', 'auto');
print('DoS_2n4p_cocktail','-dpng','-r300');
close;

function dydt = DoS(Time,y,p) 
%% Parameters (based from Allie's model/supplementary) %%

%If density drops below 1 cell, then the population has died out completely 
y(y < 1e-9) = 0;

%Growth rates and relative plasmid burdens%
alphad = [1/1.21 1/1.3]; %Natural burden of DoS plasmid
alphaf = [1/0.81 1/0.9]; %Natural burden of conjugative plasmid
K = 1; %Carrying capacity

%Antibiotic
burden = 1-p{2}; %Degree of Cm suppression of growth
benefit = 1+p{2};  %Degree of Cm growth benefit

%Dilution
D = p{1}; %Allie number is 0.05, dilution rate in Hr-1 (reflects 10^4 daily dilution fold)

%Growth%
subpop = p{5};
growth = [repmat(0.33, 1, 16) repmat(0.3, 1, 16)];
B = ones(1,32);

% %Growth matrix
% B(subpop(:,2) == 1 | subpop(:,4) == 1) = alphaf*burden;
% B(subpop(:,2) == 1 & subpop(:,4) == 1)  = alphaf^2*burden^2;
% B(subpop(:,3) == 1 | subpop(:,5) == 1) = benefit;
% %Overwrites B for special cases
% B(subpop(:,2) == 1 & (subpop(:,3) == 1 | subpop(:,5) == 1)) = alphaf*benefit;
% B(subpop(:,4) == 1 & (subpop(:,3) == 1 | subpop(:,5) == 1)) = alphaf*benefit;
% B((subpop(:,2) == 1 & subpop(:,4) == 1) & (subpop(:,3) == 1 | subpop(:,5) == 1)) = alphaf^2*benefit;

%Growth matrix
B(subpop(:,2) == 1) = alphaf(1)*burden;
B(subpop(:,4) == 1) = alphaf(2)*burden;
B(subpop(:,2) == 1 & subpop(:,4) == 1)  = prod(alphaf)*burden;
B(subpop(:,3) == 1) = alphad(1)*benefit;
B(subpop(:,5) == 1) = alphad(2)*benefit;
%Overwrites B for special cases
B(subpop(:,2) == 1 & (subpop(:,3) == 1)) = alphaf(1)*alphad(1)*benefit;
B(subpop(:,2) == 1 & (subpop(:,5) == 1)) = alphaf(1)*alphad(2)*benefit;
B(subpop(:,4) == 1 & (subpop(:,3) == 1)) = alphaf(2)*alphad(1)*benefit;
B(subpop(:,4) == 1 & (subpop(:,5) == 1)) = alphaf(2)*alphad(2)*benefit;
B((subpop(:,2) == 1 & subpop(:,4) == 1) & (subpop(:,3) == 1)) = prod(alphaf)*alphad(1)*benefit;
B((subpop(:,2) == 1 & subpop(:,4) == 1) & (subpop(:,5) == 1)) = prod(alphaf)*alphad(2)*benefit;

u = growth.*B;

%Segregation error
sigmaD = 1e-4; %Segregation error of DoS
sigmaC = 1e-4; %Segregation error of conjugative plasmid

% Conjugation rates%
etaF0 = 1.76e-3; %Allie's number for RP4

%Cotransfer/Retrotransfer
etaF1 = etaF0/10; %Conjugation of conjugative plasmid (suppressed by DoS)
etaD = etaF0; %Conjugation of DoS becomes the same as base number from experimental data
etaB = etaF0/100; %Conjugation of both plasmids
etaRet = etaF0/100; %1% of all conjugation events become retrotransfer (hence the observed 100-fold slower)

%Translating conjugation variables%
etaF = [etaF0 etaF1];
etaDf = etaD;
etaBf = etaB;

etaR = 0.9*etaF;
etaDr = 0.9*etaD;
etaBr = 0.9*etaB;

%Incompatibility (the same rate as growth)
gamma = [0.33 0.3]; 

%% ODEs %%
%This is a full model of the long term experiments 
%M_0000: empty cells%
dydt(1,1) = u(1)*y(1)*(1-sum(y)/K)...
    - etaF(1)*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0000
    - etaR(1)*y(1)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 0000
    - (etaF(2)+etaDf+etaBf)*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0000 (co)
    - (etaR(2)+etaDr+etaBr)*y(1)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0000 (co)
    + sigmaD*(y(2)+y(4)) + sigmaC*(y(3)+y(5)) - D*y(1);
%M_000D: Cells with DDoS-R%
dydt(2,1) = u(2)*y(2)*(1-sum(y)/K)...
    + etaDr*y(1)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0000
    - etaR(1)*y(2)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 000D
    - etaR(2)*y(2)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 000D
    - etaF(1)*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 000D
    - (etaF(2)+etaDf+etaBf)*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... RD__ + 000D (co)
    - etaRet*y(2)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 000D (retro)
    + gamma(1)*y(6) + sigmaC*y(9) + sigmaD*y(7) - sigmaD*y(2) - D*y(2);
%M_00R0: Cells with RP4%
dydt(3,1) = u(3)*y(3)*(1-sum(y)/K)...
    + etaR(1)*y(1)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 0000
    + etaR(2)*y(1)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0000
    - etaF(1)*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 00R0
    - (etaF(2)+etaDr+etaBr)*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00R0 (co)
    - etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(3)... 00R0 + __0D (retro)
    + gamma(1)*y(6) + sigmaC*y(10) + sigmaD*y(8) - sigmaC*y(3) - D*y(3);
%M_0D00: Cells with DDoS-F%
dydt(4,1) = u(4)*y(4)*(1-sum(y)/K)...
    + etaDf*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0000
    - etaF(1)*y(4)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D00
    - etaF(2)*y(4)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0D00
    - etaR(1)*y(4)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 0D00
    - (etaR(2)+etaDr+etaBr)*y(4)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0D00 (co)
    - etaRet*y(4)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D00 (retro)
    + gamma(1)*y(11) + sigmaC*y(8) + sigmaD*y(7) - sigmaD*y(4) - D*y(4);
%M_F000: Cells with pOX38%
dydt(5,1) = u(5)*y(5)*(1-sum(y)/K)...
    + etaF(1)*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0000
    + etaF(2)*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0000
    - etaR(1)*y(5)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F000
    - (etaR(2)+etaDr+etaBr)*y(5)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + F000 (co)
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(5)... F000 + 0D__ (retro)
    + gamma(1)*y(11) + sigmaC*y(10) + sigmaD*y(9) - sigmaC*y(5) - D*y(5);
%M_00RD: Cells with RP4 and DDoS-R
dydt(6,1) = u(6)*y(6)*(1-sum(y)/K)...
    + etaR(1)*y(2)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 000D
    + etaR(2)*y(2)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 000D
    + etaBr*y(1)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0000 (co)
    + etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(3)... 00R0 + __0D (retro)
    + etaRet*y(2)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 000D (retro, double up counted)
    - etaF(1)*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 00RD
    - (etaF(2)+etaDf+etaBf)*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00RD (co)
    + sigmaC*y(13) + sigmaD*y(12) - gamma(1)*y(6) - D*y(6);
%M_0D0D: Cells with DDoS-F and DDoS-R%
dydt(7,1) = u(7)*y(7)*(1-sum(y)/K)...
    + etaDf*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 000D
    + etaDr*y(4)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0D00
    - etaF(1)*y(7)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D0D
    - etaF(2)*y(7)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0D0D
    - etaR(1)*y(7)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... 00R0 + 0D0D
    - etaR(2)*y(7)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... 00RD + 0D0D
    - etaRet*y(7)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D0D (retro)
    - etaRet*y(7)*sum(y(subpop(:,4) == 1 & subpop(:,5)) == 0) ... __R0 + 0D0D (retro)
    + gamma(1)*y(14) + gamma(1)*y(12) - 2*sigmaD*y(7) - D*y(7);
%M_0DR0: Cells with DDoS-F and RP4%
dydt(8,1) = u(8)*y(8)*(1-sum(y)/K)...
    + etaDf*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00R0
    + etaR(1)*y(4)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... 00R0 + 0D00
    + etaR(2)*y(4)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... 00RD + 0D00
    - etaF(1)*y(8)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0DR0
    - etaF(2)*y(8)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0DR0
    - etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(8)... 0DR0 + __0D (retro)
    - etaRet*y(8)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0DR0 (retro)
    + gamma(1)*y(12) + gamma(1)*y(15) - sigmaC*y(8) - sigmaD*y(8) - D*y(8);
%M_F00D: Cells with pOX38 and DDoS-R%
dydt(9,1) = u(9)*y(9)*(1-sum(y)/K)...
    + etaDr*y(5)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + F000
    + etaF(1)*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 000D
    + etaF(2)*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 000D
    - etaR(1)*y(9)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F00D
    - etaR(2)*y(9)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + F00D
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(9)... F00D + 0D__ (retro)
    - etaRet*y(9)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F00D (retro)
    + gamma(1)*y(14) + gamma(1)*y(13) - sigmaC*y(9) - sigmaD*y(9) - D*y(9);
%M_F0R0: Cells with pOX38 and RP4%
dydt(10,1) = u(10)*y(10)*(1-sum(y)/K)...
    + etaF(1)*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 00R0
    + etaF(2)*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00R0
    + etaR(1)*y(5)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F000
    + etaR(2)*y(5)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + F000
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(10)... F0R0 + 0D__ (retro)
    - etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(10)... F0R0 + __0D (retro)
    + gamma(1)*y(15) + gamma(1)*y(13) - 2*sigmaC*y(10) - D*y(10);
%M_FD00: Cells with pOX38 and DDoS-F%
dydt(11,1) = u(11)*y(11)*(1-sum(y)/K)...
    + etaF(1)*y(4)*sum(y(subpop(:,2) == 1))... F0__ + 0D00
    + etaF(2)*y(4)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0D00
    + etaBf*y(1)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0000 (co)
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(5)... F000 + 0D__ (retro)
    + etaRet*y(4)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D00 (retro, double up counted)
    - etaR(1)*y(11)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + FD00
    - (etaR(2)+etaDr+etaBr)*y(11)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + FD00
    - gamma(1)*y(11) + sigmaC*y(15) + sigmaD*y(14) - D*y(11);
%M_0DRD: Cells with DDoS-F, RP4, and DDoS-R%
dydt(12,1) = u(12)*y(12)*(1-sum(y)/K)...
    + etaDf*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00RD
    + etaR(1)*y(7)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 0D0D
    + etaR(2)*y(7)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0D0D
    + etaBr*y(4)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0D00
    + etaRet*y(7)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 0D0D (retro)
    + etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(8)... 0DR0 + __0D (retro, double up counted)
    - etaF(1)*y(12)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0DRD
    - etaF(2)*y(12)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0DRD
    - etaRet*y(12)*sum(y(subpop(:,2) == 1 & subpop(:,5) == 0))... F0__ + 0DRD (retro)
    + gamma(1)*y(16) - gamma(1)*y(12) - sigmaD*y(12) - D*y(12);
%M_F0RD: Cells with pOX38, RP4, and DDoS-R%
dydt(13,1) = u(13)*y(13)*(1-sum(y)/K)...
    + etaF(1)*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 00RD
    + etaF(2)*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00RD
    + etaR(1)*y(9)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F00D
    + etaR(2)*y(9)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + F00D
    + etaBr*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))*y(5)... __RD + F000
    + etaRet*y(9)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F00D (retro)
    + etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(10)...F0R0 + __0D (retro, double up counted)
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(13)... F0RD + 0D__ (retro)
    + gamma(1)*y(16) - gamma(1)*y(13) - sigmaC*y(13) - D*y(13);
%M_FD0D: Cells with pOX38, DDOS-F, and DDoS-R%
dydt(14,1) = u(14)*y(14)*(1-sum(y)/K)...
    + etaDr*y(11)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + FD00
    + etaF(1)*y(7)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D0D
    + etaF(2)*y(7)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0D0D
    + etaBf*y(2)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 000D
    + etaRet*y(7)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D0D (retro)
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(9)... F00D + 0D__ (retro, double up counted)
    - etaR(1)*y(14)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + FD0D
    - etaR(2)*y(14)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + FD0D
    - etaRet*y(14)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + FD0D (retro)
    + gamma(1)*y(16) - gamma(1)*y(14) - sigmaD*y(14) - D*y(14);
%M_FDR0: Cells with pOX38, DDoS-F, and RP4%
dydt(15,1) = u(15)*y(15)*(1-sum(y)/K)...
    + etaF(1)*y(8)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0DR0
    + etaF(2)*y(8)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0DR0
    + etaR(1)*y(11)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + FD00
    + etaR(2)*y(11)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + FD00
    + etaBf*y(3)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00R0
    + etaRet*y(8)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... FD__ + 0DR0 (retro)
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(10)... F0R0 + 0D__ (retro, double up counted)
    - etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(15)... FDR0 + __0D (retro)
    + gamma(1)*y(16) - gamma(1)*y(15) - sigmaC*y(15) - D*y(15);
%M_FDRD: Cells with p0X38, DDoS-F, RP4, and DDoS-R%
dydt(16,1) = u(16)*y(16)*(1-sum(y)/K)...
    + etaF(1)*y(12)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0111
    + etaF(2)*y(12)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0111
    + etaR(1)*y(14)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 1101
    + etaR(2)*y(14)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 1101
    + etaBf*y(6)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0011
    + etaBr*y(11)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... RD__ + 1100
    + etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(15)... FDR0 + __0D (retro)
    + etaRet*y(14)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + FD0D (retro, double up counted)
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(13)... F0RD + 0D__ (retro)
    + etaRet*y(12)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0DRD (retro, double up counted)
    - 2*gamma(1)*y(16) - D*y(16);


%T_0000: empty cells%
dydt(17,1) = u(17)*y(17)*(1-sum(y)/K)...
    - etaF(1)*y(17)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0000
    - etaR(1)*y(17)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 0000
    - (etaF(2)+etaDf+etaBf)*y(17)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0000 (co)
    - (etaR(2)+etaDr+etaBr)*y(17)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0000 (co)
    + sigmaD*(y(18)+y(20)) + sigmaC*(y(19)+y(21)) - D*y(17);
%T_000D: Cells with DDoS-R%
dydt(18,1) = u(18)*y(18)*(1-sum(y)/K)...
    + etaDr*y(17)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0000
    - etaR(1)*y(18)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 000D
    - etaR(2)*y(18)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 000D
    - etaF(1)*y(18)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 000D
    - (etaF(2)+etaDf+etaBf)*y(18)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... RD__ + 000D (co)
    - etaRet*y(18)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 000D (retro)
    + gamma(2)*y(22) + sigmaC*y(25) + sigmaD*y(23) - sigmaD*y(18) - D*y(18);
%T_00R0: Cells with RP4%
dydt(19,1) = u(19)*y(19)*(1-sum(y)/K)...
    + etaR(1)*y(17)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 0000
    + etaR(2)*y(17)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0000
    - etaF(1)*y(19)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 00R0
    - (etaF(2)+etaDr+etaBr)*y(19)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00R0 (co)
    - etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(19)... 00R0 + __0D (retro)
    + gamma(2)*y(22) + sigmaC*y(26) + sigmaD*y(24) - sigmaC*y(19) - D*y(19);
%T_0D00: Cells with DDoS-F%
dydt(20,1) = u(20)*y(20)*(1-sum(y)/K)...
    + etaDf*y(17)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0000
    - etaF(1)*y(20)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D00
    - etaF(2)*y(20)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0D00
    - etaR(1)*y(20)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 0D00
    - (etaR(2)+etaDr+etaBr)*y(20)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0D00 (co)
    - etaRet*y(20)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D00 (retro)
    + gamma(2)*y(27) + sigmaC*y(24) + sigmaD*y(23) - sigmaD*y(20) - D*y(20);
%T_F000: Cells with pOX38%
dydt(21,1) = u(21)*y(21)*(1-sum(y)/K)...
    + etaF(1)*y(17)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0000
    + etaF(2)*y(17)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0000
    - etaR(1)*y(21)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F000
    - (etaR(2)+etaDr+etaBr)*y(21)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + F000 (co)
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(21)... F000 + 0D__ (retro)
    + gamma(2)*y(27) + sigmaC*y(26) + sigmaD*y(25) - sigmaC*y(21) - D*y(21);
%T_00RD: Cells with RP4 and DDoS-R
dydt(22,1) = u(22)*y(22)*(1-sum(y)/K)...
    + etaR(1)*y(18)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 000D
    + etaR(2)*y(18)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 000D
    + etaBr*y(17)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0000 (co)
    + etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(19)... 00R0 + __0D (retro)
    + etaRet*y(18)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 000D (retro, double up counted)
    - etaF(1)*y(22)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 00RD
    - (etaF(2)+etaDf+etaBf)*y(22)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00RD (co)
    + sigmaC*y(29) + sigmaD*y(28) - gamma(2)*y(22) - D*y(22);
%T_0D0D: Cells with DDoS-F and DDoS-R%
dydt(23,1) = u(23)*y(23)*(1-sum(y)/K)...
    + etaDf*y(18)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 000D
    + etaDr*y(20)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0D00
    - etaF(1)*y(23)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D0D
    - etaF(2)*y(23)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0D0D
    - etaR(1)*y(23)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... 00R0 + 0D0D
    - etaR(2)*y(23)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... 00RD + 0D0D
    - etaRet*y(23)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D0D (retro)
    - etaRet*y(23)*sum(y(subpop(:,4) == 1 & subpop(:,5)) == 0) ... __R0 + 0D0D (retro)
    + gamma(2)*y(30) + gamma(2)*y(28) - 2*sigmaD*y(23) - D*y(23);
%T_0DR0: Cells with DDoS-F and RP4%
dydt(24,1) = u(24)*y(24)*(1-sum(y)/K)...
    + etaDf*y(19)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00R0
    + etaR(1)*y(20)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... 00R0 + 0D00
    + etaR(2)*y(20)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... 00RD + 0D00
    - etaF(1)*y(24)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0DR0
    - etaF(2)*y(24)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0DR0
    - etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(24)... 0DR0 + __0D (retro)
    - etaRet*y(24)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0DR0 (retro)
    + gamma(2)*y(28) + gamma(2)*y(31) - sigmaC*y(24) - sigmaD*y(24) - D*y(24);
%T_F00D: Cells with pOX38 and DDoS-R%
dydt(25,1) = u(25)*y(25)*(1-sum(y)/K)...
    + etaDr*y(21)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + F000
    + etaF(1)*y(18)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 000D
    + etaF(2)*y(18)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 000D
    - etaR(1)*y(25)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F00D
    - etaR(2)*y(25)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + F00D
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(25)... F00D + 0D__ (retro)
    - etaRet*y(25)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F00D (retro)
    + gamma(2)*y(30) + gamma(2)*y(29) - sigmaC*y(25) - sigmaD*y(25) - D*y(25);
%T_F0R0: Cells with pOX38 and RP4%
dydt(26,1) = u(26)*y(26)*(1-sum(y)/K)...
    + etaF(1)*y(19)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 00R0
    + etaF(2)*y(19)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00R0
    + etaR(1)*y(21)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F000
    + etaR(2)*y(21)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + F000
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(26)... F0R0 + 0D__ (retro)
    - etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(26)... F0R0 + __0D (retro)
    + gamma(2)*y(31) + gamma(2)*y(29) - 2*sigmaC*y(26) - D*y(26);
%T_FD00: Cells with pOX38 and DDoS-F%
dydt(27,1) = u(27)*y(27)*(1-sum(y)/K)...
    + etaF(1)*y(20)*sum(y(subpop(:,2) == 1))... F0__ + 0D00
    + etaF(2)*y(20)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0D00
    + etaBf*y(17)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0000 (co)
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(21)... F000 + 0D__ (retro)
    + etaRet*y(20)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D00 (retro, double up counted)
    - etaR(1)*y(27)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + FD00
    - (etaR(2)+etaDr+etaBr)*y(27)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + FD00
    - gamma(2)*y(27) + sigmaC*y(31) + sigmaD*y(30) - D*y(27);
%T_0DRD: Cells with DDoS-F, RP4, and DDoS-R%
dydt(28,1) = u(28)*y(28)*(1-sum(y)/K)...
    + etaDf*y(22)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00RD
    + etaR(1)*y(23)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 0D0D
    + etaR(2)*y(23)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0D0D
    + etaBr*y(20)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 0D00
    + etaRet*y(23)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 0D0D (retro)
    + etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(24)... 0DR0 + __0D (retro, double up counted)
    - etaF(1)*y(28)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0DRD
    - etaF(2)*y(28)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0DRD
    - etaRet*y(28)*sum(y(subpop(:,2) == 1 & subpop(:,5) == 0))... F0__ + 0DRD (retro)
    + gamma(2)*y(32) - gamma(2)*y(28) - sigmaD*y(28) - D*y(28);
%T_F0RD: Cells with pOX38, RP4, and DDoS-R%
dydt(29,1) = u(29)*y(29)*(1-sum(y)/K)...
    + etaF(1)*y(22)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 00RD
    + etaF(2)*y(22)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00RD
    + etaR(1)*y(25)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F00D
    + etaR(2)*y(25)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + F00D
    + etaBr*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))*y(21)... __RD + F000
    + etaRet*y(25)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + F00D (retro)
    + etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(26)...F0R0 + __0D (retro, double up counted)
    - etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(29)... F0RD + 0D__ (retro)
    + gamma(2)*y(32) - gamma(2)*y(29) - sigmaC*y(29) - D*y(29);
%T_FD0D: Cells with pOX38, DDOS-F, and DDoS-R%
dydt(30,1) = u(30)*y(30)*(1-sum(y)/K)...
    + etaDr*y(27)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + FD00
    + etaF(1)*y(23)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D0D
    + etaF(2)*y(23)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0D0D
    + etaBf*y(18)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 000D
    + etaRet*y(23)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0D0D (retro)
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(25)... F00D + 0D__ (retro, double up counted)
    - etaR(1)*y(30)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + FD0D
    - etaR(2)*y(30)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + FD0D
    - etaRet*y(30)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + FD0D (retro)
    + gamma(2)*y(32) - gamma(2)*y(30) - sigmaD*y(30) - D*y(30);
%T_FDR0: Cells with pOX38, DDoS-F, and RP4%
dydt(31,1) = u(31)*y(31)*(1-sum(y)/K)...
    + etaF(1)*y(24)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0DR0
    + etaF(2)*y(24)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0DR0
    + etaR(1)*y(27)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + FD00
    + etaR(2)*y(27)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + FD00
    + etaBf*y(19)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 00R0
    + etaRet*y(24)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... FD__ + 0DR0 (retro)
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(26)... F0R0 + 0D__ (retro, double up counted)
    - etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(31)... FDR0 + __0D (retro)
    + gamma(2)*y(32) - gamma(2)*y(31) - sigmaC*y(31) - D*y(31);
%T_FDRD: Cells with p0X38, DDoS-F, RP4, and DDoS-R%
dydt(32,1) = u(32)*y(32)*(1-sum(y)/K)...
    + etaF(1)*y(28)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0111
    + etaF(2)*y(28)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0111
    + etaR(1)*y(30)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + 1101
    + etaR(2)*y(30)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... __RD + 1101
    + etaBf*y(22)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 1))... FD__ + 0011
    + etaBr*y(27)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 1))... RD__ + 1100
    + etaRet*sum(y(subpop(:,4) == 0 & subpop(:,5) == 1))*y(31)... FDR0 + __0D (retro)
    + etaRet*y(30)*sum(y(subpop(:,4) == 1 & subpop(:,5) == 0))... __R0 + FD0D (retro, double up counted)
    + etaRet*sum(y(subpop(:,2) == 0 & subpop(:,3) == 1))*y(29)... F0RD + 0D__ (retro)
    + etaRet*y(28)*sum(y(subpop(:,2) == 1 & subpop(:,3) == 0))... F0__ + 0DRD (retro, double up counted)
    - 2*gamma(2)*y(32) - D*y(32);

